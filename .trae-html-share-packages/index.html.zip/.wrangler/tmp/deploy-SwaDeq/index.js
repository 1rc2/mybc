var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker/index.js
var FRONTEND_HTML = '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>GitHub \u4EE4\u724C\u7BA1\u7406</title>\n<style>\n  /* ===== \u5168\u5C40\u91CD\u7F6E + \u6DF1\u8272\u4E3B\u9898 ===== */\n  * { box-sizing: border-box; margin: 0; padding: 0; }\n  html, body { height: 100%; }\n  body {\n    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;\n    background: #0d1117;\n    color: #e6edf3;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    min-height: 100vh;\n  }\n\n  /* ===== \u767B\u5F55\u9875 ===== */\n  .login-wrap {\n    width: 360px;\n    background: #161b22;\n    border: 1px solid #30363d;\n    border-radius: 12px;\n    padding: 32px;\n    box-shadow: 0 8px 24px rgba(0,0,0,0.5);\n  }\n  .login-wrap h1 {\n    font-size: 20px;\n    margin-bottom: 6px;\n    color: #4e9acd;\n  }\n  .login-wrap .sub {\n    font-size: 13px;\n    color: #8b949e;\n    margin-bottom: 24px;\n  }\n  .login-wrap label {\n    display: block;\n    font-size: 13px;\n    color: #8b949e;\n    margin: 10px 0 6px;\n  }\n  .login-wrap input {\n    width: 100%;\n    height: 40px;\n    padding: 0 40px 0 12px; /* \u53F3\u4FA7\u7559\u51FA\u773C\u775B\u6309\u94AE\u7A7A\u95F4 */\n    background: #0d1117;\n    border: 1px solid #30363d;\n    border-radius: 8px;\n    color: #e6edf3;\n    font-size: 14px;\n    outline: none;\n    transition: border-color .15s;\n  }\n  .login-wrap input:focus { border-color: #4e9acd; }\n\n  /* \u5BC6\u7801\u884C\u5BB9\u5668\uFF1A\u76F8\u5BF9\u5B9A\u4F4D\uFF0C\u8BA9\u773C\u775B\u6309\u94AE\u7EDD\u5BF9\u5B9A\u4F4D\u53E0\u5728\u8F93\u5165\u6846\u5185\u90E8\u53F3\u4FA7 */\n  .pwd-row {\n    position: relative;\n  }\n  .pwd-row input {\n    padding-right: 40px;\n  }\n  .eye-btn {\n    position: absolute;\n    right: 4px;\n    top: 50%;\n    transform: translateY(-50%);\n    width: 32px;\n    height: 32px;\n    background: transparent;\n    border: none;\n    border-radius: 6px;\n    cursor: pointer;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    transition: background .15s;\n  }\n  .eye-btn:hover { background: rgba(78,154,205,0.12); }\n  .eye-btn:active { background: rgba(78,154,205,0.2); }\n  .eye-btn svg {\n    width: 18px;\n    height: 18px;\n    fill: none;\n    stroke: #8b949e;\n    stroke-width: 2;\n    stroke-linecap: round;\n    stroke-linejoin: round;\n  }\n  .eye-btn:hover svg { stroke: #4e9acd; }\n\n  /* \u767B\u5F55\u6309\u94AE\uFF1A\u53EA\u5339\u914D\u76F4\u63A5\u5B50\u7EA7\u7684 #loginBtn\uFF0C\u522B\u8BEF\u4F24 .pwd-row \u91CC\u7684 .eye-btn */\n  .login-wrap > button#loginBtn {\n    width: 100%;\n    height: 40px;\n    margin-top: 18px;\n    background: #4e9acd;\n    border: none;\n    border-radius: 8px;\n    color: #fff;\n    font-size: 15px;\n    cursor: pointer;\n    transition: background .15s;\n  }\n  .login-wrap > button#loginBtn:hover { background: #3d8ab9; }\n  .login-wrap > button#loginBtn:disabled { background: #3a3f4a; cursor: not-allowed; }\n  .err-msg {\n    color: #f97583;\n    font-size: 13px;\n    margin-top: 10px;\n    min-height: 18px;\n  }\n\n  /* \u767B\u5F55\u9875\u5E95\u90E8\uFF1A\u63A5\u53E3\u5730\u5740 + \u8FDE\u63A5\u72B6\u6001 */\n  .login-footer {\n    margin-top: 16px;\n    padding-top: 14px;\n    border-top: 1px dashed #30363d;\n    font-size: 12px;\n    color: #8b949e;\n    line-height: 1.8;\n    word-break: break-all;\n  }\n  .login-footer .status-ok { color: #3fb950; }\n  .login-footer .status-bad { color: #f97583; }\n  .login-footer .status-wait { color: #8b949e; }\n\n  /* ===== \u4E3B\u9875\u9762 ===== */\n  .main-wrap {\n    width: 100%;\n    max-width: 560px;\n    padding: 20px;\n  }\n  .main-header {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    margin-bottom: 24px;\n  }\n  .main-header h1 {\n    font-size: 18px;\n    color: #4e9acd;\n  }\n  .main-header button {\n    height: 32px;\n    padding: 0 14px;\n    background: transparent;\n    border: 1px solid #30363d;\n    border-radius: 6px;\n    color: #c9d1d9;\n    font-size: 13px;\n    cursor: pointer;\n  }\n  .main-header button:hover { border-color: #4e9acd; color: #4e9acd; }\n\n  /* ===== \u4EE4\u724C\u66F4\u65B0\u5361\u7247 ===== */\n  .card {\n    background: #161b22;\n    border: 1px solid #30363d;\n    border-radius: 12px;\n    padding: 28px;\n  }\n  .card h2 {\n    font-size: 18px;\n    color: #4e9acd;\n    margin-bottom: 8px;\n  }\n  .card .hint {\n    font-size: 13px;\n    color: #8b949e;\n    line-height: 1.6;\n    margin-bottom: 20px;\n  }\n\n  /* ===== \u5F53\u524D\u4EE4\u724C\u72B6\u6001 ===== */\n  .current-token {\n    background: #0d1117;\n    border: 1px solid #30363d;\n    border-radius: 8px;\n    padding: 14px 16px;\n    margin-bottom: 20px;\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    gap: 12px;\n  }\n  .current-token .label {\n    font-size: 12px;\n    color: #8b949e;\n    margin-bottom: 4px;\n  }\n  .current-token .value {\n    font-size: 14px;\n    color: #e6edf3;\n    font-family: "Menlo", "Consolas", monospace;\n    word-break: break-all;\n  }\n  .current-token .value.empty { color: #f85149; }\n  .current-token .refresh-btn {\n    flex-shrink: 0;\n    height: 30px;\n    padding: 0 12px;\n    background: transparent;\n    border: 1px solid #30363d;\n    border-radius: 6px;\n    color: #8b949e;\n    font-size: 12px;\n    cursor: pointer;\n  }\n  .current-token .refresh-btn:hover { border-color: #4e9acd; color: #4e9acd; }\n  .current-token .refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }\n  .card label {\n    display: block;\n    font-size: 13px;\n    color: #8b949e;\n    margin: 14px 0 6px;\n  }\n  .card .input-row {\n    display: flex;\n    gap: 10px;\n  }\n  .card input {\n    flex: 1;\n    height: 42px;\n    padding: 0 12px;\n    background: #0d1117;\n    border: 1px solid #30363d;\n    border-radius: 8px;\n    color: #e6edf3;\n    font-size: 14px;\n    outline: none;\n    font-family: "Menlo", "Consolas", monospace;\n    transition: border-color .15s;\n  }\n  .card input:focus { border-color: #4e9acd; }\n  .btn-toggle {\n    width: 60px;\n    height: 42px;\n    background: transparent;\n    border: 1px solid #30363d;\n    border-radius: 8px;\n    color: #8b949e;\n    font-size: 13px;\n    cursor: pointer;\n  }\n  .btn-toggle:hover { border-color: #4e9acd; color: #4e9acd; }\n  .btn-submit {\n    width: 100%;\n    height: 42px;\n    margin-top: 14px;\n    background: #4e9acd;\n    border: none;\n    border-radius: 8px;\n    color: #fff;\n    font-size: 15px;\n    cursor: pointer;\n  }\n  .btn-submit:hover { background: #3d8ab9; }\n  .btn-submit:disabled { background: #3a3f4a; cursor: not-allowed; }\n\n  /* ===== \u7ED3\u679C\u63D0\u793A ===== */\n  .result {\n    margin-top: 16px;\n    padding: 12px 14px;\n    border-radius: 8px;\n    font-size: 13px;\n    line-height: 1.6;\n    display: none;\n  }\n  .result.success {\n    display: block;\n    background: rgba(63, 185, 80, 0.12);\n    border: 1px solid #2ea043;\n    color: #3fb950;\n  }\n  .result.error {\n    display: block;\n    background: rgba(248, 81, 73, 0.12);\n    border: 1px solid #f85149;\n    color: #ff7b72;\n  }\n  .result.warn {\n    display: block;\n    background: rgba(210, 153, 34, 0.12);\n    border: 1px solid #d29922;\n    color: #e3b341;\n  }\n\n  /* ===== \u6EDA\u52A8\u6761 ===== */\n  ::-webkit-scrollbar { width: 8px; }\n  ::-webkit-scrollbar-track { background: #0d1117; }\n  ::-webkit-scrollbar-thumb { background: #30363d; border-radius: 4px; }\n  ::-webkit-scrollbar-thumb:hover { background: #4e9acd; }\n</style>\n</head>\n<body>\n\n<!-- ===== \u767B\u5F55\u9875 ===== -->\n<div class="login-wrap" id="loginPage">\n  <h1>GitHub \u4EE4\u724C\u7BA1\u7406</h1>\n  <div id="modeLabel" style="font-size:12px;color:#4e9acd;margin:-4px 0 8px;"></div>\n  <p class="sub">\u767B\u5F55\u540E\u7BA1\u7406\u4F60\u7684 GitHub \u4E2A\u4EBA\u8BBF\u95EE\u4EE4\u724C</p>\n  <label for="username">\u8D26\u53F7</label>\n  <input id="username" type="text" autocomplete="username" placeholder="\u8BF7\u8F93\u5165\u8D26\u53F7">\n  <label for="password">\u5BC6\u7801</label>\n  <div class="pwd-row">\n    <input id="password" type="password" autocomplete="current-password" placeholder="\u8BF7\u8F93\u5165\u5BC6\u7801">\n    <button type="button" class="eye-btn" onclick="toggleLoginPwd()" id="loginEye" title="\u663E\u793A/\u9690\u85CF\u5BC6\u7801">\n      <svg id="eyeOpen" viewBox="0 0 24 24">\n        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>\n        <circle cx="12" cy="12" r="3"/>\n      </svg>\n      <svg id="eyeClose" viewBox="0 0 24 24" style="display:none">\n        <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a19.77 19.77 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a19.6 19.6 0 0 1-3.17 4.19M1 1l22 22"/>\n        <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/>\n      </svg>\n    </button>\n  </div>\n  <button id="loginBtn" onclick="doLogin()">\u767B\u5F55</button>\n  <div class="err-msg" id="loginErr"></div>\n\n  <!-- \u5E95\u90E8\uFF1A\u63A5\u53E3\u5730\u5740 + \u8FDE\u63A5\u72B6\u6001\uFF08\u65B9\u4FBF\u6392\u9519 Failed to fetch\uFF09 -->\n  <div class="login-footer">\n    <div>\u63A5\u53E3\uFF1A<span id="workerUrlDisplay">-</span></div>\n    <div>\u8FDE\u63A5\uFF1A<span id="workerStatus" class="status-wait">\u68C0\u6D4B\u4E2D...</span></div>\n  </div>\n</div>\n\n<!-- ===== \u4E3B\u9875\u9762\uFF08\u767B\u5F55\u540E\u663E\u793A\uFF09 ===== -->\n<div class="main-wrap" id="mainPage" style="display:none">\n  <div class="main-header">\n    <h1>GitHub \u4EE4\u724C\u7BA1\u7406</h1>\n    <button onclick="doLogout()">\u9000\u51FA\u767B\u5F55</button>\n  </div>\n  <div class="card">\n    <h2>\u66F4\u65B0 GitHub \u4E2A\u4EBA\u8BBF\u95EE\u4EE4\u724C</h2>\n    <p class="hint">\u8F93\u5165\u65B0\u7684 GitHub PAT\uFF08Personal Access Token\uFF09\uFF0C\u63D0\u4EA4\u540E\u7ACB\u5373\u751F\u6548\u3002\u82E5\u5DF2\u914D\u7F6E Cloudflare API \u51ED\u8BC1\uFF0C\u4EE4\u724C\u5C06\u6301\u4E45\u5316\u5199\u5165 Worker \u73AF\u5883\u53D8\u91CF\uFF0C\u91CD\u542F\u540E\u4ECD\u6709\u6548\u3002</p>\n\n    <!-- \u5F53\u524D\u4EE4\u724C\u72B6\u6001\uFF08\u8131\u654F\u9884\u89C8\uFF0C\u4ECE\u540E\u7AEF /api/get-token \u83B7\u53D6\uFF09 -->\n    <div class="current-token">\n      <div>\n        <div class="label">\u5F53\u524D\u4EE4\u724C</div>\n        <div class="value empty" id="currentToken">\u52A0\u8F7D\u4E2D...</div>\n      </div>\n      <button class="refresh-btn" id="refreshBtn" onclick="loadCurrentToken()">\u5237\u65B0</button>\n    </div>\n\n    <label for="patInput">\u65B0\u7684 GitHub \u4EE4\u724C</label>\n    <div class="input-row">\n      <input id="patInput" type="password" autocomplete="off" placeholder="ghp_xxxxxxxxxxxx \u6216 github_pat_xxxxxxxxxxxx">\n      <button class="btn-toggle" onclick="toggleVisibility()" id="toggleBtn">\u663E\u793A</button>\n    </div>\n    <button class="btn-submit" id="updateBtn" onclick="updatePat()">\u63D0\u4EA4\u66F4\u65B0</button>\n    <div class="result" id="result"></div>\n  </div>\n</div>\n\n<script>/* ============================================================\n * \u524D\u7AEF\u6838\u5FC3 JS \u2014\u2014 \u53CC\u6A21\u5F0F\uFF08Worker / GitHub\uFF09\u81EA\u52A8\u5207\u6362\n * \u5B89\u5168\u8BBE\u8BA1\uFF1A\n *   1) \u4E3B\u5BC6\u7801\u53EA\u5728\u5185\u5B58\u77ED\u6682\u5B58\u5728\uFF08\u6BCF\u6B21\u8F93\u5165\uFF0ClocalStorage \u4E0D\u5B58\uFF09\n *   2) \u771F\u5B9E PAT \u7528\u5B8C\u7ACB\u5373\u8986\u76D6 null\uFF08\u5185\u5B58\u5373\u6E05\uFF09\n *   3) GitHub Mode \u4E0B Gist/Contents \u6587\u4EF6\u5B58 AES-256-GCM \u5BC6\u6587 blob\n *   4) PBKDF2-SHA256 \u6D3E\u751F\u5BC6\u94A5 100000 \u8F6E\n * ============================================================ */\n\n// ===== \u6A21\u5F0F\u81EA\u52A8\u5224\u65AD =====\n// *.workers.dev \u57DF\u540D => Worker Mode\uFF08\u540C\u6E90\u540E\u7AEF\uFF0C\u5BC6\u94A5\u5B58 Cloudflare \u73AF\u5883\u53D8\u91CF\uFF09\n// \u5176\u4ED6\u57DF\u540D => GitHub Mode\uFF08Repository Contents + AES \u52A0\u5BC6\uFF0C\u591A\u8BBE\u5907\u540C\u6B65\uFF09\nconst MODE = location.hostname.endsWith(".workers.dev") ? "worker" : "github";\nconst API_BASE = MODE === "worker" ? "" : "https://api.github.com";\nconst GITHUB_REPO = "1rc2/mybc";\nconst GITHUB_FILE = ".sync-data/token_store.json";\nconst PBKDF2_ITER = 100000;\n\n// ===== \u4F1A\u8BDD\u72B6\u6001\uFF08\u5168\u90E8\u4EC5\u5B58\u5185\u5B58\uFF0C\u7EDD\u4E0D\u5199\u5165 localStorage\uFF09=====\nlet _sessionPwd = null;        // \u4E3B\u5BC6\u7801\uFF08\u4EC5\u5185\u5B58\uFF0C\u5173\u95ED\u9875\u9762\u5373\u6E05\uFF09\nlet _sessionRealPat = null;    // \u89E3\u5BC6\u51FA\u7684\u771F\u5B9E\u4EE4\u724C\uFF08\u7528\u5B8C\u5373\u6E05\uFF09\nlet _clearRealPat = null;      // \u81EA\u52A8\u6E05\u7406\u5B9A\u65F6\u5668\u53E5\u67C4\n\n// ===== \u52A0\u5BC6\u5DE5\u5177\uFF08Web Crypto API\uFF0C\u6D4F\u89C8\u5668\u539F\u751F\u5B9E\u73B0\uFF09=====\nasync function pbkdf2DeriveKey(password, salt) {\n  const enc = new TextEncoder();\n  const keyMaterial = await crypto.subtle.importKey(\n    "raw", enc.encode(password), "PBKDF2", false, ["deriveKey"]\n  );\n  return await crypto.subtle.deriveKey(\n    { name: "PBKDF2", salt, iterations: PBKDF2_ITER, hash: "SHA-256" },\n    keyMaterial,\n    { name: "AES-GCM", length: 256 },\n    false, ["encrypt", "decrypt"]\n  );\n}\n\nasync function aesGcmEncrypt(key, plaintext) {\n  const iv = crypto.getRandomValues(new Uint8Array(12));\n  const enc = new TextEncoder();\n  const ciphertext = await crypto.subtle.encrypt(\n    { name: "AES-GCM", iv }, key, enc.encode(plaintext)\n  );\n  return {\n    iv: btoa(String.fromCharCode(...iv)),\n    ciphertext: btoa(String.fromCharCode(...new Uint8Array(ciphertext)))\n  };\n}\n\nasync function aesGcmDecrypt(key, ivB64, ctB64) {\n  const iv = Uint8Array.from(atob(ivB64), c => c.charCodeAt(0));\n  const ct = Uint8Array.from(atob(ctB64), c => c.charCodeAt(0));\n  const dec = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ct);\n  return new TextDecoder().decode(dec);\n}\n\n// ===== GitHub Contents API \u5C01\u88C5 =====\nasync function ghApi(method, path, token, body) {\n  const opts = {\n    method,\n    headers: {\n      "Authorization": "Bearer " + token,\n      "Accept": "application/vnd.github.v3+json",\n      "Content-Type": "application/json"\n    }\n  };\n  if (body) opts.body = JSON.stringify(body);\n  return fetch(API_BASE + path, opts);\n}\n\nasync function ghGetStore(token) {\n  const res = await ghApi("GET", `/repos/${GITHUB_REPO}/contents/${encodeURIComponent(GITHUB_FILE)}`, token);\n  if (res.status === 404) return { ok: true, exists: false };\n  if (!res.ok) return { ok: false, error: "GitHub API " + res.status };\n  const d = await res.json();\n  const content = JSON.parse(atob(d.content));\n  return { ok: true, exists: true, sha: d.sha, data: content };\n}\n\nasync function ghPutStore(token, encrypted, sha) {\n  const content = btoa(JSON.stringify({\n    ...encrypted,\n    version: 2,\n    updated_at: new Date().toISOString()\n  }));\n  const body = { message: "sync: update encrypted token store", content };\n  if (sha) body.sha = sha;\n  const res = await ghApi("PUT", `/repos/${GITHUB_REPO}/contents/${encodeURIComponent(GITHUB_FILE)}`, token, body);\n  return { ok: res.ok, status: res.status };\n}\n\n// ===== \u663E\u793A\u8131\u654F\u503C =====\nfunction maskPat(pat) {\n  if (!pat) return "\uFF08\u7A7A\uFF09";\n  if (pat.length <= 8) return "****";\n  return pat.slice(0, 6) + "****" + pat.slice(-4);\n}\n\n// ===== \u542F\u52A8\uFF1A\u6839\u636E MODE \u663E\u793A\u5BF9\u5E94\u767B\u5F55 =====\nwindow.addEventListener("DOMContentLoaded", () => {\n  if (MODE === "worker") {\n    // Worker Mode\uFF1A\u539F admin/admin \u767B\u5F55\n    document.getElementById("modeLabel").textContent = "\u{1F535} Worker \u6A21\u5F0F\uFF08\u5BC6\u94A5\u5B58 Cloudflare\uFF09";\n  } else {\n    // GitHub Mode\uFF1A\u4E3B\u5BC6\u7801 + \u5B58\u50A8 PAT\n    document.getElementById("modeLabel").textContent = "\u{1F7E2} GitHub \u6A21\u5F0F\uFF08AES \u52A0\u5BC6\u591A\u8BBE\u5907\u540C\u6B65\uFF09";\n    // \u628A"\u8D26\u53F7"\u6539\u6210"\u5B58\u50A8 PAT"\uFF0C"\u5BC6\u7801"\u6539\u6210"\u4E3B\u5BC6\u7801"\n    const u = document.getElementById("username");\n    const p = document.getElementById("password");\n    document.querySelector(\'label[for="username"]\').textContent = "\u5B58\u50A8 PAT\uFF08\u5199\u4ED3\u5E93\u6743\u9650\uFF09";\n    document.querySelector(\'label[for="password"]\').textContent = "\u4E3B\u5BC6\u7801\uFF08\u6BCF\u6B21\u8F93\u5165\uFF0C\u4E0D\u4FDD\u5B58\uFF09";\n    u.placeholder = "ghp_... \u53EA\u6709 repo scope \u5373\u53EF";\n    p.placeholder = "\u52A0\u5BC6\u7528\u4E3B\u5BC6\u7801\uFF08\u8BF7\u7262\u8BB0\uFF09";\n  }\n  // \u5065\u5EB7\u68C0\u67E5 + \u767B\u5F55\u72B6\u6001\u68C0\u6D4B\n  if (MODE === "worker" && localStorage.getItem("github_pat_token")) {\n    showMain();\n  } else {\n    showLogin();\n    checkBackendHealth();\n  }\n});\n\nfunction showLogin() {\n  document.getElementById("loginPage").style.display = "";\n  document.getElementById("mainPage").style.display = "none";\n}\nfunction showMain() {\n  document.getElementById("loginPage").style.display = "none";\n  document.getElementById("mainPage").style.display = "";\n  document.getElementById("patInput").focus();\n  loadCurrentToken();\n}\n\n// ===== \u767B\u5F55 =====\nasync function doLogin() {\n  const uEl = document.getElementById("username");\n  const pEl = document.getElementById("password");\n  const errEl = document.getElementById("loginErr");\n  const btn = document.getElementById("loginBtn");\n  const u = uEl.value.trim();\n  const p = pEl.value;\n  errEl.textContent = "";\n  if (!u || !p) { errEl.textContent = "\u8BF7\u586B\u5199\u5B8C\u6574"; return; }\n  btn.disabled = true; btn.textContent = "\u767B\u5F55\u4E2D...";\n\n  if (MODE === "worker") {\n    // Worker Mode\uFF1APOST /api/login\n    const res = await fetch(API_BASE + "/api/login", {\n      method: "POST",\n      headers: { "Content-Type": "application/json" },\n      body: JSON.stringify({ username: u, password: p })\n    });\n    let data = {};\n    try { data = await res.json(); } catch {}\n    if (res.ok && data.token) {\n      localStorage.setItem("github_pat_token", data.token);\n      showMain();\n    } else {\n      errEl.textContent = data.error || "\u767B\u5F55\u5931\u8D25";\n    }\n  } else {\n    // GitHub Mode\uFF1A\u9A8C\u8BC1 PAT\uFF0C\u4E3B\u5BC6\u7801\u4EC5\u5B58\u5185\u5B58\uFF08localStorage \u4E0D\u5B58\uFF09\n    const res = await ghApi("GET", "/user", u);\n    if (!res.ok) {\n      errEl.textContent = "PAT \u65E0\u6548\u6216\u6743\u9650\u4E0D\u8DB3\uFF08GitHub API " + res.status + "\uFF09";\n    } else {\n      _sessionPwd = p;                          // \u4E3B\u5BC6\u7801\u4EC5\u5B58\u5185\u5B58\n      localStorage.setItem("gh_sync_pat", u);   // \u53EA\u5B58"\u7528\u4E8E\u8BFB\u5199\u4ED3\u5E93"\u7684 PAT\n      pEl.value = "";                           // \u6E05\u7A7A\u5BC6\u7801\u8F93\u5165\u6846\n      showMain();\n    }\n  }\n  btn.disabled = false; btn.textContent = "\u767B\u5F55";\n}\n\n// ===== \u52A0\u8F7D\u5F53\u524D\u4EE4\u724C =====\nasync function loadCurrentToken() {\n  const el = document.getElementById("currentToken");\n  const btn = document.getElementById("refreshBtn");\n  btn.disabled = true;\n  if (MODE === "worker") {\n    const t = localStorage.getItem("github_pat_token");\n    if (!t) { el.textContent = "\uFF08\u672A\u767B\u5F55\uFF09"; btn.disabled = false; return; }\n    const res = await fetch(API_BASE + "/api/get-token", {\n      headers: { "Authorization": "Bearer " + t }\n    });\n    let data = {}; try { data = await res.json(); } catch {}\n    if (res.status === 401) { localStorage.removeItem("github_pat_token"); showLogin(); return; }\n    if (data.hasToken && data.preview) { el.className = "value"; el.textContent = data.preview; }\n    else { el.className = "value empty"; el.textContent = "\uFF08\u672A\u8BBE\u7F6E\uFF09"; }\n  } else {\n    // GitHub Mode\uFF1A\u8BFB\u53D6\u52A0\u5BC6\u5B58\u50A8\u5E76\u89E3\u5BC6\n    const pat = localStorage.getItem("gh_sync_pat");\n    if (!pat) { el.textContent = "\uFF08\u672A\u767B\u5F55\uFF09"; btn.disabled = false; return; }\n    const g = await ghGetStore(pat);\n    if (!g.ok) {\n      el.className = "value empty";\n      el.textContent = "\u26A0\uFE0F \u8BFB\u53D6\u5931\u8D25\uFF1A" + g.error;\n      btn.disabled = false; return;\n    }\n    if (!g.exists || !g.data.encrypted) {\n      el.className = "value empty";\n      el.textContent = "\uFF08\u672A\u8BBE\u7F6E\uFF0C\u8BF7\u5728\u4E0B\u65B9\u8F93\u5165\u65B0\u4EE4\u724C\u5E76\u63D0\u4EA4\uFF09";\n      btn.disabled = false; return;\n    }\n    // \u4E3B\u5BC6\u7801\u4F18\u5148\u7528\u4F1A\u8BDD\u5185\u5B58\uFF0C\u7F3A\u5931\u65F6\u624D\u8BE2\u95EE\uFF08\u4E0D\u843D localStorage\uFF09\n    const pwd = _sessionPwd || prompt("\u8BF7\u8F93\u5165\u4E3B\u5BC6\u7801\uFF08\u89E3\u5BC6\u7528\uFF09\uFF1A");\n    if (!pwd) { el.className = "value empty"; el.textContent = "\uFF08\u5DF2\u53D6\u6D88\uFF09"; btn.disabled = false; return; }\n    try {\n      const salt = Uint8Array.from(atob(g.data.salt), c => c.charCodeAt(0));\n      const key = await pbkdf2DeriveKey(pwd, salt);\n      const plain = await aesGcmDecrypt(key, g.data.iv, g.data.encrypted);\n      _sessionPwd = pwd;                 // \u8BB0\u4F4F\u672C\u6B21\u4F1A\u8BDD\u4E3B\u5BC6\u7801\uFF08\u4EC5\u5185\u5B58\uFF09\n      el.className = "value";\n      el.textContent = maskPat(plain);\n      _sessionRealPat = plain;           // \u771F\u5B9E\u4EE4\u724C\u77ED\u6682\u5728\u5185\u5B58\n      if (_clearRealPat) clearTimeout(_clearRealPat);\n      _clearRealPat = setTimeout(() => { _sessionRealPat = null; }, 30000);  // 30 \u79D2\u540E\u81EA\u52A8\u6E05\n    } catch (e) {\n      _sessionPwd = null;                // \u5BC6\u7801\u9519\u8BEF\u5219\u6E05\u6389\uFF0C\u907F\u514D\u53CD\u590D\u7528\u9519\u5BC6\u7801\n      el.className = "value empty";\n      el.textContent = "\u26A0\uFE0F \u4E3B\u5BC6\u7801\u9519\u8BEF\uFF08\u65E0\u6CD5\u89E3\u5BC6\uFF09";\n    }\n  }\n  btn.disabled = false;\n}\n\n// ===== \u66F4\u65B0\u4EE4\u724C\uFF08\u6838\u5FC3\u529F\u80FD\uFF09=====\nasync function updatePat() {\n  const input = document.getElementById("patInput");\n  const btn = document.getElementById("updateBtn");\n  const newPat = input.value.trim();\n  if (!newPat) { showResult("error", "\u8BF7\u8F93\u5165\u65B0\u4EE4\u724C"); return; }\n  btn.disabled = true; btn.textContent = "\u63D0\u4EA4\u4E2D...";\n\n  if (MODE === "worker") {\n    const t = localStorage.getItem("github_pat_token");\n    if (!t) { showLogin(); btn.disabled = false; btn.textContent = "\u63D0\u4EA4\u66F4\u65B0"; return; }\n    const res = await fetch(API_BASE + "/api/update-key", {\n      method: "POST",\n      headers: {\n        "Content-Type": "application/json",\n        "Authorization": "Bearer " + t\n      },\n      body: JSON.stringify({ apiKey: newPat })\n    });\n    let data = {}; try { data = await res.json(); } catch {}\n    if (res.status === 401) { localStorage.removeItem("github_pat_token"); showLogin(); return; }\n    if (data.persisted) showResult("success", data.message || "\u2705 \u5DF2\u6301\u4E45\u5316");\n    else showResult("warn", data.message || "\u5DF2\u5728\u5185\u5B58\u751F\u6548");\n    input.value = ""; loadCurrentToken();\n  } else {\n    // GitHub Mode\uFF1AAES \u52A0\u5BC6\u540E\u5199\u56DE\u4ED3\u5E93\uFF08\u591A\u8BBE\u5907\u540C\u6B65\uFF09\n    const pat = localStorage.getItem("gh_sync_pat");\n    if (!pat) { showLogin(); btn.disabled = false; btn.textContent = "\u63D0\u4EA4\u66F4\u65B0"; return; }\n\n    const g = await ghGetStore(pat);\n    if (!g.ok) {\n      showResult("error", "\u8BFB\u53D6\u5B58\u50A8\u5931\u8D25\uFF1A" + g.error);\n      btn.disabled = false; btn.textContent = "\u63D0\u4EA4\u66F4\u65B0"; return;\n    }\n    const sha = (g.exists && g.sha) ? g.sha : null;\n\n    // \u53D6\u4E3B\u5BC6\u7801\uFF1A\u4F18\u5148\u4F1A\u8BDD\u5185\u5B58\uFF0C\u7F3A\u5931\u65F6\u8BE2\u95EE\uFF08\u4E0D\u843D localStorage\uFF09\n    const pwd = _sessionPwd || prompt("\u8BF7\u8F93\u5165\u4E3B\u5BC6\u7801\uFF08\u52A0\u5BC6\u7528\uFF09\uFF1A");\n    if (!pwd) { btn.disabled = false; btn.textContent = "\u63D0\u4EA4\u66F4\u65B0"; return; }\n\n    // salt\uFF1A\u5DF2\u6709\u5219\u590D\u7528\uFF08\u4FDD\u8BC1\u540C\u4E00\u5BC6\u7801\u53EF\u8DE8\u8BBE\u5907\u89E3\u5BC6\uFF09\uFF0C\u9996\u6B21\u5219\u968F\u673A\u751F\u6210\n    const saltArr = (g.exists && g.data.salt)\n      ? Uint8Array.from(atob(g.data.salt), c => c.charCodeAt(0))\n      : crypto.getRandomValues(new Uint8Array(16));\n\n    const key = await pbkdf2DeriveKey(pwd, saltArr);\n    const enc = await aesGcmEncrypt(key, newPat);\n    const write = await ghPutStore(pat, {\n      salt: btoa(String.fromCharCode(...saltArr)),\n      encrypted: enc.ciphertext,\n      iv: enc.iv\n    }, sha);\n\n    if (write.ok) {\n      _sessionPwd = pwd;   // \u6210\u529F\u540E\u8BB0\u4F4F\u672C\u6B21\u4F1A\u8BDD\u5BC6\u7801\uFF08\u4EC5\u5185\u5B58\uFF09\n      showResult("success", "\u2705 \u5DF2\u52A0\u5BC6\u4FDD\u5B58\uFF0C\u5176\u4ED6\u8BBE\u5907\u5237\u65B0\u5373\u53EF\u540C\u6B65");\n      input.value = "";\n      _sessionRealPat = null;              // \u7528\u5B8C\u5373\u6E05\n      if (_clearRealPat) clearTimeout(_clearRealPat);\n      loadCurrentToken();\n    } else if (write.status === 409) {\n      showResult("error", "\u5199\u5165\u51B2\u7A81\uFF08\u6587\u4EF6\u5DF2\u88AB\u5176\u4ED6\u8BBE\u5907\u4FEE\u6539\uFF09\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5");\n    } else {\n      showResult("error", "\u5199\u5165\u5931\u8D25\uFF08HTTP " + write.status + "\uFF09");\n    }\n  }\n  btn.disabled = false; btn.textContent = "\u63D0\u4EA4\u66F4\u65B0";\n}\n\n// ===== \u9000\u51FA\u767B\u5F55\uFF1A\u6E05\u9664\u6240\u6709\u672C\u5730\u72B6\u6001 =====\nfunction doLogout() {\n  if (MODE === "worker") {\n    localStorage.removeItem("github_pat_token");\n  } else {\n    localStorage.removeItem("gh_sync_pat");\n  }\n  // \u65E0\u8BBA\u54EA\u79CD\u6A21\u5F0F\uFF0C\u90FD\u6E05\u7A7A\u5185\u5B58\u4E2D\u7684\u654F\u611F\u72B6\u6001\n  _sessionPwd = null;\n  _sessionRealPat = null;\n  if (_clearRealPat) { clearTimeout(_clearRealPat); _clearRealPat = null; }\n  showLogin();\n  document.getElementById("username").value = "";\n  document.getElementById("password").value = "";\n  document.getElementById("patInput").value = "";\n  document.getElementById("result").className = "result";\n  document.getElementById("result").textContent = "";\n  checkBackendHealth();\n}\n\n// ===== \u5BC6\u7801\u6846\u5C0F\u773C\u775B =====\nfunction toggleLoginPwd() {\n  const input = document.getElementById("password");\n  input.type = input.type === "password" ? "text" : "password";\n}\n\n// ===== \u540E\u7AEF\u5065\u5EB7\u68C0\u67E5\uFF08\u6A21\u5F0F\u9002\u914D\uFF09=====\nasync function checkBackendHealth() {\n  const urlEl = document.getElementById("workerUrlDisplay");\n  const statusEl = document.getElementById("workerStatus");\n  if (!urlEl) return;\n  if (MODE === "worker") {\n    urlEl.textContent = API_BASE || location.origin + "\uFF08Worker \u540E\u7AEF\uFF09";\n    statusEl.textContent = "\u68C0\u6D4B\u4E2D...";\n    statusEl.className = "status-wait";\n    try {\n      const res = await fetch(API_BASE + "/health");\n      if (res.ok) { statusEl.textContent = "\u2705 Worker \u5DF2\u8FDE\u63A5"; statusEl.className = "status-ok"; }\n      else { statusEl.textContent = "\u274C HTTP " + res.status; statusEl.className = "status-bad"; }\n    } catch (e) {\n      statusEl.textContent = "\u274C \u65E0\u6CD5\u8FDE\u63A5 Worker\uFF08workers.dev \u53EF\u80FD\u4E0D\u7A33\u5B9A\uFF09";\n      statusEl.className = "status-bad";\n    }\n  } else {\n    // GitHub Mode\uFF1A\u6D4B api.github.com + \u591A\u8BBE\u5907\u540C\u6B65\u72B6\u6001\n    urlEl.textContent = "GitHub API\uFF08" + GITHUB_REPO + "/" + GITHUB_FILE + "\uFF09";\n    statusEl.textContent = "\u68C0\u6D4B\u4E2D...";\n    statusEl.className = "status-wait";\n    try {\n      const res = await fetch(API_BASE + "/rate_limit");\n      if (res.ok) {\n        // \u68C0\u67E5 .sync-data \u6587\u4EF6\u662F\u5426\u5B58\u5728\n        const pat = localStorage.getItem("gh_sync_pat");\n        if (pat) {\n          const g = await ghGetStore(pat);\n          if (g.ok && g.exists) {\n            statusEl.textContent = "\u2705 GitHub API + \u591A\u8BBE\u5907\u540C\u6B65\u53EF\u7528";\n          } else {\n            statusEl.textContent = "\u26A0\uFE0F \u5B58\u50A8\u6587\u4EF6\u672A\u521D\u59CB\u5316\uFF08\u9996\u6B21\u4F7F\u7528\u4F1A\u81EA\u52A8\u521B\u5EFA\uFF09";\n          }\n        } else {\n          statusEl.textContent = "\u2705 GitHub API \u53EF\u8FBE\uFF0C\u8BF7\u767B\u5F55\u4EE5\u542F\u7528\u591A\u8BBE\u5907\u540C\u6B65";\n        }\n        statusEl.className = "status-ok";\n      } else { statusEl.textContent = "\u274C GitHub API HTTP " + res.status; statusEl.className = "status-bad"; }\n    } catch (e) {\n      statusEl.textContent = "\u274C \u65E0\u6CD5\u8FDE\u63A5 GitHub API"; statusEl.className = "status-bad";\n    }\n  }\n}\n\n// ===== \u7ED3\u679C\u63D0\u793A =====\nfunction showResult(type, text) {\n  const el = document.getElementById("result");\n  el.className = "result " + type;\n  el.textContent = text;\n}\n\n// ===== \u9875\u9762\u5173\u95ED/\u5237\u65B0\u65F6\u6E05\u7A7A\u5185\u5B58\u4E2D\u7684\u654F\u611F\u6570\u636E =====\nwindow.addEventListener("beforeunload", () => {\n  _sessionPwd = null;\n  _sessionRealPat = null;\n});\n<\/script>\n</body>\n</html>\n';
var tokenStore = /* @__PURE__ */ new Map();
var TOKEN_TTL = 1e3 * 60 * 60 * 12;
var tokenOverride = null;
var index_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(request) });
    }
    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
      return new Response(FRONTEND_HTML, {
        status: 200,
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-cache"
        }
      });
    }
    if (url.pathname === "/api/login" && request.method === "POST") {
      return handleLogin(request, env);
    }
    if (url.pathname === "/api/update-key" && request.method === "POST") {
      return handleUpdateKey(request, env);
    }
    if (url.pathname === "/api/get-token" && request.method === "GET") {
      return handleGetToken(request, env);
    }
    if (url.pathname === "/health") {
      return json({ ok: true }, 200, request);
    }
    return json({ error: "Not Found" }, 404, request);
  }
};
async function handleLogin(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "\u8BF7\u6C42\u4F53\u683C\u5F0F\u9519\u8BEF\uFF0C\u5E94\u4E3A JSON" }, 400, request);
  }
  const { username, password } = body || {};
  if (!username || !password) {
    return json({ error: "\u8D26\u53F7\u548C\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A" }, 400, request);
  }
  if (username !== env.USER_NAME || password !== env.USER_PASS) {
    return json({ error: "\u8D26\u53F7\u6216\u5BC6\u7801\u9519\u8BEF" }, 401, request);
  }
  const token = generateToken();
  tokenStore.set(token, Date.now() + TOKEN_TTL);
  return json({ token }, 200, request);
}
__name(handleLogin, "handleLogin");
async function handleUpdateKey(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token || !isTokenValid(token)) {
    return json({ error: "token \u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55" }, 401, request);
  }
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "\u8BF7\u6C42\u4F53\u683C\u5F0F\u9519\u8BEF\uFF0C\u5E94\u4E3A JSON" }, 400, request);
  }
  const { apiKey } = body || {};
  if (!apiKey || typeof apiKey !== "string") {
    return json({ error: "\u65B0\u4EE4\u724C\u4E0D\u80FD\u4E3A\u7A7A" }, 400, request);
  }
  const trimmed = apiKey.trim();
  if (!trimmed) {
    return json({ error: "\u65B0\u4EE4\u724C\u4E0D\u80FD\u4E3A\u7A7A" }, 400, request);
  }
  tokenOverride = trimmed;
  const cfToken = env.CF_API_TOKEN;
  const cfAccountId = env.CF_ACCOUNT_ID;
  const cfWorkerName = env.CF_WORKER_NAME;
  if (!cfToken || !cfAccountId || !cfWorkerName) {
    return json({
      ok: true,
      persisted: false,
      message: "\u4EE4\u724C\u5DF2\u66F4\u65B0\uFF08\u4EC5\u5F53\u524D\u5B9E\u4F8B\u751F\u6548\uFF0CWorker \u91CD\u542F\u540E\u5931\u6548\uFF09\u3002\u5982\u9700\u6301\u4E45\u5316\uFF0C\u8BF7\u914D\u7F6E CF_API_TOKEN\u3001CF_ACCOUNT_ID\u3001CF_WORKER_NAME\u3002"
    }, 200, request);
  }
  try {
    const persisted = await updateEnvVarViaCfApi(cfToken, cfAccountId, cfWorkerName, "GITHUB_TOKEN", trimmed);
    if (persisted) {
      return json({
        ok: true,
        persisted: true,
        message: "\u4EE4\u724C\u5DF2\u66F4\u65B0\u5E76\u6301\u4E45\u5316\u5230 Worker \u73AF\u5883\u53D8\u91CF GITHUB_TOKEN\uFF0C\u91CD\u542F\u540E\u4ECD\u6709\u6548\u3002"
      }, 200, request);
    } else {
      return json({
        ok: false,
        persisted: false,
        error: "\u4EE4\u724C\u5DF2\u5728\u5185\u5B58\u4E2D\u751F\u6548\uFF0C\u4F46\u5199\u5165\u73AF\u5883\u53D8\u91CF\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5 CF_API_TOKEN \u6743\u9650\u53CA CF_ACCOUNT_ID/CF_WORKER_NAME\u3002"
      }, 500, request);
    }
  } catch (e) {
    return json({
      ok: false,
      persisted: false,
      error: "\u4EE4\u724C\u5DF2\u5728\u5185\u5B58\u4E2D\u751F\u6548\uFF0C\u4F46\u8C03\u7528 Cloudflare API \u51FA\u9519\uFF1A" + e.message
    }, 500, request);
  }
}
__name(handleUpdateKey, "handleUpdateKey");
async function handleGetToken(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token || !isTokenValid(token)) {
    return json({ error: "token \u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55" }, 401, request);
  }
  const pat = tokenOverride || env.GITHUB_TOKEN;
  if (!pat) {
    return json({ hasToken: false, preview: "" }, 200, request);
  }
  const preview = pat.length > 12 ? pat.slice(0, 4) + "****" + pat.slice(-4) : "****";
  return json({ hasToken: true, preview }, 200, request);
}
__name(handleGetToken, "handleGetToken");
async function updateEnvVarViaCfApi(cfToken, accountId, workerName, varName, newValue) {
  const apiBase = "https://api.cloudflare.com/client/v4";
  const secretUrl = `${apiBase}/accounts/${accountId}/workers/scripts/${workerName}/secrets/${varName}`;
  const headers = {
    "Authorization": `Bearer ${cfToken}`,
    "Content-Type": "application/json"
  };
  const putRes = await fetch(`${secretUrl}?force=true`, {
    method: "PUT",
    headers,
    body: JSON.stringify({ name: varName, text: newValue, type: "secret_text" })
  });
  if (!putRes.ok) {
    console.error("CF API PUT secret failed:", putRes.status);
    return false;
  }
  const putJson = await putRes.json();
  if (!putJson.success) {
    console.error("CF API PUT secret errors:", JSON.stringify(putJson.errors));
    return false;
  }
  return true;
}
__name(updateEnvVarViaCfApi, "updateEnvVarViaCfApi");
function isTokenValid(token) {
  const exp = tokenStore.get(token);
  if (!exp) return false;
  if (Date.now() > exp) {
    tokenStore.delete(token);
    return false;
  }
  return true;
}
__name(isTokenValid, "isTokenValid");
function generateToken() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  const hex = Array.from(arr).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex + "_" + Date.now().toString(36);
}
__name(generateToken, "generateToken");
function corsHeaders(request) {
  let origin = "*";
  if (request) {
    origin = request.headers.get("Origin") || "*";
  }
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}
__name(corsHeaders, "corsHeaders");
function json(obj, status, request) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders(request)
    }
  });
}
__name(json, "json");
export {
  index_default as default
};
//# sourceMappingURL=index.js.map
